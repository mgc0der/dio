package com.dio.springmvcbasico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringmvcbasicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
